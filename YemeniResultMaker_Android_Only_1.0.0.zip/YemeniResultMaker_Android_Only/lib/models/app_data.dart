import 'dart:convert';

class Subject {
  String id;
  String name;
  Subject({required this.id, required this.name});
  Map<String,dynamic> toJson()=>{'id':id,'name':name};
  factory Subject.fromJson(Map<String,dynamic> j)=>Subject(id:j['id']??'',name:j['name']??'');
}

class Student {
  String id;
  String name;
  String grade;
  Map<String,double> first20;
  Map<String,double> first30;
  Map<String,double> second20;
  Map<String,double> final30;

  Student({
    required this.id, required this.name, required this.grade,
    Map<String,double>? first20, Map<String,double>? first30,
    Map<String,double>? second20, Map<String,double>? final30,
  }): first20=first20??{}, first30=first30??{}, second20=second20??{}, final30=final30??{};

  Map<String,dynamic> toJson()=> {
    'id':id,'name':name,'grade':grade,
    'first20':first20,'first30':first30,'second20':second20,'final30':final30
  };

  factory Student.fromJson(Map<String,dynamic> j)=>Student(
    id:j['id']??'',name:j['name']??'',grade:j['grade']??'',
    first20:Map<String,double>.from((j['first20']??{}).map((k,v)=>MapEntry(k,(v as num).toDouble()))),
    first30:Map<String,double>.from((j['first30']??{}).map((k,v)=>MapEntry(k,(v as num).toDouble()))),
    second20:Map<String,double>.from((j['second20']??{}).map((k,v)=>MapEntry(k,(v as num).toDouble()))),
    final30:Map<String,double>.from((j['final30']??{}).map((k,v)=>MapEntry(k,(v as num).toDouble()))),
  );
}

class AppSettings {
  String educationOffice;
  String schoolName;
  String district;
  String academicYear;
  String controllerName;
  String principalName;
  String? logoPath;

  AppSettings({
    this.educationOffice='مكتب التربية والتعليم',
    this.schoolName='مدرسة ____________________',
    this.district='مديرية ____________________',
    this.academicYear='2026 / 2027',
    this.controllerName='',
    this.principalName='',
    this.logoPath,
  });

  Map<String,dynamic> toJson()=> {
    'educationOffice':educationOffice,'schoolName':schoolName,'district':district,
    'academicYear':academicYear,'controllerName':controllerName,
    'principalName':principalName,'logoPath':logoPath
  };

  factory AppSettings.fromJson(Map<String,dynamic> j)=>AppSettings(
    educationOffice:j['educationOffice']??'مكتب التربية والتعليم',
    schoolName:j['schoolName']??'مدرسة ____________________',
    district:j['district']??'مديرية ____________________',
    academicYear:j['academicYear']??'2026 / 2027',
    controllerName:j['controllerName']??'',
    principalName:j['principalName']??'',
    logoPath:j['logoPath'],
  );
}

class AppData {
  List<Subject> subjects;
  List<Student> students;
  AppSettings settings;

  AppData({required this.subjects,required this.students,required this.settings});

  static AppData defaults()=>AppData(
    subjects:[
      Subject(id:'quran',name:'قرآن كريم'),
      Subject(id:'islamic',name:'إسلامية'),
      Subject(id:'arabic',name:'لغة عربية'),
      Subject(id:'math',name:'رياضيات'),
      Subject(id:'science',name:'علوم'),
      Subject(id:'national',name:'وطنية'),
    ],
    students:[],
    settings:AppSettings(),
  );

  Map<String,dynamic> toJson()=> {
    'subjects':subjects.map((e)=>e.toJson()).toList(),
    'students':students.map((e)=>e.toJson()).toList(),
    'settings':settings.toJson(),
  };

  factory AppData.fromJson(Map<String,dynamic> j)=>AppData(
    subjects:(j['subjects'] as List? ?? []).map((e)=>Subject.fromJson(Map<String,dynamic>.from(e))).toList(),
    students:(j['students'] as List? ?? []).map((e)=>Student.fromJson(Map<String,dynamic>.from(e))).toList(),
    settings:AppSettings.fromJson(Map<String,dynamic>.from(j['settings']??{})),
  );

  String encode()=>jsonEncode(toJson());
  static AppData decode(String s)=>AppData.fromJson(jsonDecode(s));
}
