import '../models/app_data.dart';

class StudentResult {
  final Student student;
  final double firstTotal;
  final double finalTotal;
  final double percentage;
  final bool passed;
  StudentResult({
    required this.student,required this.firstTotal,required this.finalTotal,
    required this.percentage,required this.passed
  });
}

class CalculationService {
  static double clamp(double value,double max)=>value<0?0:(value>max?max:value);

  static double firstSubject(Student s,Subject sub){
    return clamp(s.first20[sub.id]??0,20)+clamp(s.first30[sub.id]??0,30);
  }

  static double finalSubject(Student s,Subject sub){
    return firstSubject(s,sub)+clamp(s.second20[sub.id]??0,20)+clamp(s.final30[sub.id]??0,30);
  }

  static StudentResult result(Student s,List<Subject> subjects){
    final first=subjects.fold<double>(0,(a,b)=>a+firstSubject(s,b));
    final fin=subjects.fold<double>(0,(a,b)=>a+finalSubject(s,b));
    return StudentResult(
      student:s, firstTotal:first, finalTotal:fin,
      percentage: subjects.isEmpty?0:fin/(subjects.length*100)*100,
      passed:fin >= subjects.length*50,
    );
  }

  static List<StudentResult> ranked(List<Student> students,List<Subject> subjects,{required bool finalSemester}){
    final list=students.map((s)=>result(s,subjects)).toList();
    list.sort((a,b){
      final aa=finalSemester?a.finalTotal:a.firstTotal;
      final bb=finalSemester?b.finalTotal:b.firstTotal;
      final c=bb.compareTo(aa);
      return c!=0?c:a.student.name.compareTo(b.student.name);
    });
    return list;
  }
}
