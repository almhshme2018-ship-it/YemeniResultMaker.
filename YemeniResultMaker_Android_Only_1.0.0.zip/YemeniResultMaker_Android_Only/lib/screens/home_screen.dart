import 'package:flutter/material.dart';
import '../models/app_data.dart';
import '../services/storage_service.dart';
import 'students_screen.dart';
import 'grade_entry_screen.dart';
import 'results_screen.dart';
import 'settings_screen.dart';

class HomeScreen extends StatefulWidget {
  final AppData data;
  const HomeScreen({super.key,required this.data});
  @override State<HomeScreen> createState()=>_HomeScreenState();
}
class _HomeScreenState extends State<HomeScreen>{
  Future<void> save()=>StorageService.save(widget.data);
  @override Widget build(BuildContext context){
    final d=widget.data;
    return Scaffold(
      appBar:AppBar(title:const Text('صانع النتائج اليمني الذكي'),centerTitle:true),
      body:ListView(padding:const EdgeInsets.all(14),children:[
        Card(child:Padding(padding:const EdgeInsets.all(16),child:Column(children:[
          const Icon(Icons.school,size:46),
          const SizedBox(height:6),
          Text(d.settings.schoolName,style:const TextStyle(fontSize:19,fontWeight:FontWeight.bold)),
          Text('العام الدراسي ${d.settings.academicYear}'),
        ]))),
        _tile('الطلاب',Icons.people,()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>StudentsScreen(data:d,onChanged:save)))),
        _tile('إدخال الدرجات',Icons.edit_note,()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>GradeEntryScreen(data:d,onChanged:save)))),
        _tile('النتائج والشهادات',Icons.picture_as_pdf,()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>ResultsScreen(data:d)))),
        _tile('الإعدادات والمواد',Icons.settings,()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>SettingsScreen(data:d,onChanged:save)))),
      ])
    );
  }
  Widget _tile(String t,IconData i,VoidCallback f)=>Card(child:ListTile(leading:Icon(i),title:Text(t,style:const TextStyle(fontSize:17)),trailing:const Icon(Icons.chevron_left),onTap:f));
}
