import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'models/app_data.dart';
import 'screens/home_screen.dart';
import 'services/storage_service.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await SystemChrome.setPreferredOrientations([DeviceOrientation.portraitUp]);
  final data = await StorageService.load();
  runApp(YemeniResultMakerApp(data: data));
}

class YemeniResultMakerApp extends StatefulWidget {
  final AppData data;
  const YemeniResultMakerApp({super.key, required this.data});

  @override
  State<YemeniResultMakerApp> createState() => _YemeniResultMakerAppState();
}

class _YemeniResultMakerAppState extends State<YemeniResultMakerApp> {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'صانع النتائج اليمني الذكي',
      theme: ThemeData(
        useMaterial3: true,
        fontFamily: 'Amiri',
        colorSchemeSeed: Colors.indigo,
        scaffoldBackgroundColor: const Color(0xfff5f7fb),
      ),
      locale: const Locale('ar'),
      home: Directionality(
        textDirection: TextDirection.rtl,
        child: HomeScreen(data: widget.data),
      ),
    );
  }
}
