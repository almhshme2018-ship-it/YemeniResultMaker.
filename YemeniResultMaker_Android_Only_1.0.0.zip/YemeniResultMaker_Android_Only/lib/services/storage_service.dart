import 'package:shared_preferences/shared_preferences.dart';
import '../models/app_data.dart';

class StorageService {
  static const key='yemeni_result_maker_data';

  static Future<AppData> load() async {
    final p=await SharedPreferences.getInstance();
    final s=p.getString(key);
    if(s==null) return AppData.defaults();
    try { return AppData.decode(s); } catch (_) { return AppData.defaults(); }
  }

  static Future<void> save(AppData data) async {
    final p=await SharedPreferences.getInstance();
    await p.setString(key,data.encode());
  }
}
