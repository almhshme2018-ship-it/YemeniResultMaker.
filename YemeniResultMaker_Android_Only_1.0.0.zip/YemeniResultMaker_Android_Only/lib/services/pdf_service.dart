import 'dart:io';
import 'dart:typed_data';
import 'package:flutter/services.dart';
import 'package:path_provider/path_provider.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import '../models/app_data.dart';
import 'calculation_service.dart';

class PdfService {
  static Future<String> buildResultsPdf(AppData data,{required bool finalSemester}) async {
    final fontData=await rootBundle.load('assets/fonts/Amiri-Regular.ttf');
    final font=pw.Font.ttf(fontData);
    pw.MemoryImage? logo;
    final path=data.settings.logoPath;
    if(path!=null && path.isNotEmpty && File(path).existsSync()){
      logo=pw.MemoryImage(await File(path).readAsBytes());
    }

    final grouped=<String,List<Student>>{};
    for(final s in data.students){ grouped.putIfAbsent(s.grade,()=>[]).add(s); }

    final doc=pw.Document();
    for(final entry in grouped.entries){
      final ranked=CalculationService.ranked(entry.value,data.subjects,finalSemester:finalSemester);
      for(int start=0;start<ranked.length;start+=3){
        final pageItems=ranked.sublist(start,(start+3>ranked.length)?ranked.length:start+3);
        doc.addPage(pw.Page(
          pageFormat: PdfPageFormat.a4,
          margin: const pw.EdgeInsets.symmetric(horizontal:18,vertical:12),
          build: (_) => pw.Column(children:[
            for(int i=0;i<pageItems.length;i++) ...[
              pw.Expanded(child:_card(
                data,pageItems[i],data.subjects,font,logo,finalSemester,start+i+1
              )),
              if(i<pageItems.length-1)
                pw.Container(height:8,child:pw.Center(child:pw.Text('............................................................',style:pw.TextStyle(font:font,fontSize:7))))
            ]
          ])
        ));
      }
    }

    final dir=await getApplicationDocumentsDirectory();
    final file=File('${dir.path}/${finalSemester?"الشهادات_النهائية":"شهادات_الفصل_الأول"}.pdf');
    await file.writeAsBytes(await doc.save());
    return file.path;
  }

  static pw.Widget _card(
    AppData data,StudentResult r,List<Subject> subjects,pw.Font font,
    pw.MemoryImage? logo,bool finalSemester,int rank
  ){
    final max=subjects.length*(finalSemester?100:50);
    final total=finalSemester?r.finalTotal:r.firstTotal;
    return pw.Container(
      padding:const pw.EdgeInsets.all(7),
      decoration:pw.BoxDecoration(border:pw.Border.all(width:1.2)),
      child:pw.Column(children:[
        pw.Row(crossAxisAlignment:pw.CrossAxisAlignment.start,children:[
          pw.Expanded(child:pw.Column(crossAxisAlignment:pw.CrossAxisAlignment.start,children:[
            pw.Text('الجمهورية اليمنية',style:pw.TextStyle(font:font,fontSize:10,fontWeight:pw.FontWeight.bold)),
            pw.Text('وزارة التربية والتعليم والبحث العلمي',style:pw.TextStyle(font:font,fontSize:8)),
            pw.Text(data.settings.educationOffice,style:pw.TextStyle(font:font,fontSize:8)),
            pw.Text(data.settings.district,style:pw.TextStyle(font:font,fontSize:8)),
            pw.Text(data.settings.schoolName,style:pw.TextStyle(font:font,fontSize:8)),
          ])),
          pw.Container(width:46,height:46,decoration:pw.BoxDecoration(border:pw.Border.all()),child:
            logo!=null?pw.Image(logo,fit:pw.BoxFit.contain):pw.Center(child:pw.Text('شعار',style:pw.TextStyle(font:font,fontSize:7)))),
          pw.Expanded(child:pw.Column(crossAxisAlignment:pw.CrossAxisAlignment.end,children:[
            pw.Text(finalSemester?'كشف النتيجة النهائية':'كشف النتيجة النصفية',style:pw.TextStyle(font:font,fontSize:11,fontWeight:pw.FontWeight.bold)),
            pw.Text('العام الدراسي: ${data.settings.academicYear}',style:pw.TextStyle(font:font,fontSize:8)),
          ])),
        ]),
        pw.SizedBox(height:5),
        pw.Container(
          padding:const pw.EdgeInsets.symmetric(horizontal:5,vertical:3),
          decoration:pw.BoxDecoration(border:pw.Border.all()),
          child:pw.Row(children:[
            pw.Expanded(child:pw.Text('الطالب: ${r.student.name}',style:pw.TextStyle(font:font,fontSize:8))),
            pw.Text('الصف: ${r.student.grade}',style:pw.TextStyle(font:font,fontSize:8)),
            pw.SizedBox(width:10),
            pw.Text('المجموع: ${_fmt(total)}/$max',style:pw.TextStyle(font:font,fontSize:8)),
            pw.SizedBox(width:10),
            pw.Text(r.passed?'ناجح':'راسب',style:pw.TextStyle(font:font,fontSize:8,fontWeight:pw.FontWeight.bold)),
            pw.SizedBox(width:10),
            pw.Text('الترتيب: $rank',style:pw.TextStyle(font:font,fontSize:8)),
          ])
        ),
        pw.SizedBox(height:4),
        _table(data,subjects,r.student,font,finalSemester),
        pw.SizedBox(height:4),
        pw.Row(mainAxisAlignment:pw.MainAxisAlignment.spaceBetween,children:[
          pw.Text('الكنترول: ${data.settings.controllerName.isEmpty?"................":data.settings.controllerName}',style:pw.TextStyle(font:font,fontSize:8)),
          pw.Text('مدير المدرسة: ${data.settings.principalName.isEmpty?"................":data.settings.principalName}',style:pw.TextStyle(font:font,fontSize:8)),
        ])
      ])
    );
  }

  static pw.Widget _table(AppData data,List<Subject> subjects,Student s,pw.Font font,bool finalSemester){
    final headers=finalSemester
      ? ['المادة','المحصلة الأولى\n20','الاختبار الأول\n30','المحصلة الثانية\n20','الاختبار النهائي\n30','المجموع\n100']
      : ['المادة','المحصلة الأولى\n20','الاختبار الأول\n30','المجموع النصفي\n50'];
    final rows=<List<String>>[];
    for(final sub in subjects){
      final a=s.first20[sub.id]??0;
      final b=s.first30[sub.id]??0;
      if(finalSemester){
        final c=s.second20[sub.id]??0;
        final d=s.final30[sub.id]??0;
        rows.add([sub.name,_fmt(a),_fmt(b),_fmt(c),_fmt(d),_fmt(a+b+c+d)]);
      }else{
        rows.add([sub.name,_fmt(a),_fmt(b),_fmt(a+b)]);
      }
    }
    return pw.Table(
      border:pw.TableBorder.all(width:.6),
      columnWidths: finalSemester
        ? {0:const pw.FlexColumnWidth(2.2),1:const pw.FlexColumnWidth(1),2:const pw.FlexColumnWidth(1),3:const pw.FlexColumnWidth(1),4:const pw.FlexColumnWidth(1),5:const pw.FlexColumnWidth(1.1)}
        : {0:const pw.FlexColumnWidth(2.5),1:const pw.FlexColumnWidth(1.2),2:const pw.FlexColumnWidth(1.2),3:const pw.FlexColumnWidth(1.3)},
      children:[
        pw.TableRow(decoration:pw.BoxDecoration(color:PdfColors.grey300),children:
          headers.map((h)=>pw.Padding(padding:const pw.EdgeInsets.all(2),child:pw.Center(child:pw.Text(h,style:pw.TextStyle(font:font,fontSize:6.5,fontWeight:pw.FontWeight.bold))))).toList()),
        ...rows.map((row)=>pw.TableRow(children:row.map((v)=>pw.Padding(padding:const pw.EdgeInsets.all(2),child:pw.Center(child:pw.Text(v,style:pw.TextStyle(font:font,fontSize:7))))).toList()))
      ]
    );
  }

  static String _fmt(double v)=>v.truncateToDouble()==v?v.toInt().toString():v.toStringAsFixed(1);
}
