import 'package:flutter/material.dart';
import '../models/app_data.dart';
import '../services/calculation_service.dart';
import '../services/pdf_service.dart';
import '../services/excel_service.dart';
import '../services/share_service.dart';

class ResultsScreen extends StatefulWidget{
  final AppData data;
  const ResultsScreen({super.key,required this.data});
  @override State<ResultsScreen> createState()=>_ResultsScreenState();
}
class _ResultsScreenState extends State<ResultsScreen>{
  String grade='';
  bool finalSemester=false;

  @override Widget build(BuildContext context){
    final students=widget.data.students.where((s)=>grade.isEmpty||s.grade==grade).toList();
    final ranked=CalculationService.ranked(students,widget.data.subjects,finalSemester:finalSemester);
    return Scaffold(appBar:AppBar(title:const Text('النتائج والشهادات')),body:ListView(padding:const EdgeInsets.all(12),children:[
      Row(children:[
        Expanded(child:DropdownButtonFormField<String>(value:grade,decoration:const InputDecoration(labelText:'الصف'),items:[
          const DropdownMenuItem(value:'',child:Text('كل الصفوف')),
          ...widget.data.students.map((s)=>s.grade).toSet().where((e)=>e.isNotEmpty).map((e)=>DropdownMenuItem(value:e,child:Text(e)))
        ],onChanged:(v)=>setState(()=>grade=v??''))),
        const SizedBox(width:8),
        Expanded(child:DropdownButtonFormField<bool>(value:finalSemester,decoration:const InputDecoration(labelText:'نوع النتيجة'),items:const[
          DropdownMenuItem(value:false,child:Text('الفصل الأول')),
          DropdownMenuItem(value:true,child:Text('النهائية')),
        ],onChanged:(v)=>setState(()=>finalSemester=v??false))),
      ]),
      const SizedBox(height:10),
      FilledButton.icon(onPressed:()async{
        final path=await PdfService.buildResultsPdf(widget.data,finalSemester:finalSemester);
        await ShareService.shareFile(path);
      },icon:const Icon(Icons.print),label:Text(finalSemester?'طباعة الشهادات النهائية':'طباعة شهادات الفصل الأول')),
      OutlinedButton.icon(onPressed:()async{
        if(grade.isEmpty && students.isNotEmpty) grade=students.first.grade;
        if(grade.isEmpty)return;
        final path=await ExcelService.createClassSheet(widget.data,grade,finalSemester:finalSemester);
        await ShareService.shareFile(path);
      },icon:const Icon(Icons.table_chart),label:const Text('تصدير كشف الدرجات Excel')),
      const Divider(),
      for(int i=0;i<ranked.length;i++) Card(child:ListTile(
        leading:CircleAvatar(child:Text('${i+1}')),
        title:Text(ranked[i].student.name),
        subtitle:Text('المجموع: ${finalSemester?ranked[i].finalTotal:ranked[i].firstTotal}  •  ${ranked[i].passed?"ناجح":"راسب"}'),
      ))
    ]));
  }
}
