import 'package:flutter/material.dart';
import '../models/app_data.dart';
import '../services/storage_service.dart';

class GradeEntryScreen extends StatefulWidget{
  final AppData data; final Future<void> Function() onChanged;
  const GradeEntryScreen({super.key,required this.data,required this.onChanged});
  @override State<GradeEntryScreen> createState()=>_GradeEntryScreenState();
}
class _GradeEntryScreenState extends State<GradeEntryScreen>{
  int semester=1;
  String grade='';
  final Map<String,TextEditingController> ctrls={};
  @override void dispose(){for(final c in ctrls.values)c.dispose();super.dispose();}
  TextEditingController ctl(String id,String key,double value){
    final k='$id-$key';
    return ctrls.putIfAbsent(k,()=>TextEditingController(text:value==0?'':_fmt(value)));
  }
  String _fmt(double v)=>v.truncateToDouble()==v?v.toInt().toString():v.toStringAsFixed(1);

  @override Widget build(BuildContext context){
    final students=widget.data.students.where((s)=>grade.isEmpty||s.grade==grade).toList();
    return Scaffold(
      appBar:AppBar(title:const Text('إدخال الدرجات')),
      body:ListView(padding:const EdgeInsets.all(10),children:[
        DropdownButtonFormField<int>(value:semester,decoration:const InputDecoration(labelText:'الفصل'),items:const[
          DropdownMenuItem(value:1,child:Text('الفصل الأول')),
          DropdownMenuItem(value:2,child:Text('الفصل الثاني / النهائي')),
        ],onChanged:(v)=>setState(()=>semester=v??1)),
        const SizedBox(height:8),
        DropdownButtonFormField<String>(value:grade,decoration:const InputDecoration(labelText:'الصف'),items:[
          const DropdownMenuItem(value:'',child:Text('كل الصفوف')),
          ...widget.data.students.map((s)=>s.grade).toSet().where((e)=>e.isNotEmpty).map((e)=>DropdownMenuItem(value:e,child:Text(e)))
        ],onChanged:(v)=>setState(()=>grade=v??'')),
        const SizedBox(height:8),
        for(final s in students) _student(s),
      ])
    );
  }

  Widget _student(Student s){
    return Card(child:Padding(padding:const EdgeInsets.all(10),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
      Text(s.name,style:const TextStyle(fontSize:17,fontWeight:FontWeight.bold)),
      Text('الصف: ${s.grade}'),
      const SizedBox(height:6),
      for(final sub in widget.data.subjects) _subjectRow(s,sub),
    ])));
  }

  Widget _subjectRow(Student s,Subject sub){
    final isSecond=semester==2;
    final fields=<Widget>[
      _field(s,sub,'first20',s.first20[sub.id]??0,20,'م1'),
      _field(s,sub,'first30',s.first30[sub.id]??0,30,'اخت1'),
    ];
    if(isSecond){
      fields.add(_field(s,sub,'second20',s.second20[sub.id]??0,20,'م2'));
      fields.add(_field(s,sub,'final30',s.final30[sub.id]??0,30,'نهائي'));
    }
    return Padding(padding:const EdgeInsets.symmetric(vertical:4),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
      Text(sub.name,style:const TextStyle(fontWeight:FontWeight.w600)),
      Row(children:fields.map((w)=>Expanded(child:Padding(padding:const EdgeInsets.only(left:4),child:w))).toList()),
    ]));
  }

  Widget _field(Student s,Subject sub,String key,double value,double max,String label){
    final c=ctl(sub.id+s.id,key,value);
    return TextField(controller:c,keyboardType:const TextInputType.numberWithOptions(decimal:true),
      decoration:InputDecoration(labelText:'$label / $max',isDense:true,border:const OutlineInputBorder()),
      onChanged:(v)async{
        final x=double.tryParse(v.replaceAll(',','.'))??0;
        final fixed=x.clamp(0,max).toDouble();
        if(key=='first20')s.first20[sub.id]=fixed;
        if(key=='first30')s.first30[sub.id]=fixed;
        if(key=='second20')s.second20[sub.id]=fixed;
        if(key=='final30')s.final30[sub.id]=fixed;
        await widget.onChanged();
      });
  }
}
