import 'package:flutter/material.dart';
import 'package:file_picker/file_picker.dart';
import '../models/app_data.dart';

class SettingsScreen extends StatefulWidget{
  final AppData data; final Future<void> Function() onChanged;
  const SettingsScreen({super.key,required this.data,required this.onChanged});
  @override State<SettingsScreen> createState()=>_SettingsScreenState();
}
class _SettingsScreenState extends State<SettingsScreen>{
  late TextEditingController office,school,district,year,controller,principal;
  @override void initState(){super.initState();final s=widget.data.settings;
    office=TextEditingController(text:s.educationOffice);school=TextEditingController(text:s.schoolName);
    district=TextEditingController(text:s.district);year=TextEditingController(text:s.academicYear);
    controller=TextEditingController(text:s.controllerName);principal=TextEditingController(text:s.principalName);
  }
  @override void dispose(){for(final c in [office,school,district,year,controller,principal])c.dispose();super.dispose();}
  Future<void> save()async{
    final s=widget.data.settings;s.educationOffice=office.text;s.schoolName=school.text;s.district=district.text;
    s.academicYear=year.text;s.controllerName=controller.text;s.principalName=principal.text;await widget.onChanged();
    if(mounted)ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('تم الحفظ')));
  }
  Future<void> logo()async{
    final r=await FilePicker.platform.pickFiles(type:FileType.image);
    if(r!=null && r.files.single.path!=null){widget.data.settings.logoPath=r.files.single.path;await widget.onChanged();setState((){});}
  }
  @override Widget build(BuildContext context)=>Scaffold(appBar:AppBar(title:const Text('الإعدادات')),body:ListView(padding:const EdgeInsets.all(12),children:[
    ...[
      [office,'مكتب التربية والتعليم'],[district,'المديرية'],[school,'اسم المدرسة'],[year,'العام الدراسي'],
      [controller,'اسم الكنترول'],[principal,'اسم مدير المدرسة']
    ].map((x)=>Padding(padding:const EdgeInsets.only(bottom:8),child:TextField(controller:x[0] as TextEditingController,decoration:InputDecoration(labelText:x[1] as String,border:const OutlineInputBorder())))),
    FilledButton.icon(onPressed:logo,icon:const Icon(Icons.image),label:Text(widget.data.settings.logoPath==null?'رفع شعار المدرسة':'تغيير الشعار')),
    const SizedBox(height:8),
    FilledButton.icon(onPressed:save,icon:const Icon(Icons.save),label:const Text('حفظ بيانات الرأس والتوقيعات')),
    const SizedBox(height:18),
    const Text('المواد الدراسية',style:TextStyle(fontSize:18,fontWeight:FontWeight.bold)),
    for(final sub in widget.data.subjects) ListTile(
      title:Text(sub.name),trailing:IconButton(icon:const Icon(Icons.edit),onPressed:()=>editSubject(sub)),
    ),
    OutlinedButton.icon(onPressed:()=>addSubject(),icon:const Icon(Icons.add),label:const Text('إضافة مادة')),
  ]));
  Future<void> editSubject(Subject sub)async{
    final c=TextEditingController(text:sub.name);
    await showDialog(context:context,builder:(_)=>AlertDialog(title:const Text('تعديل المادة'),content:TextField(controller:c),actions:[
      TextButton(onPressed:()=>Navigator.pop(context),child:const Text('إلغاء')),
      FilledButton(onPressed:()async{sub.name=c.text.trim();await widget.onChanged();setState((){});Navigator.pop(context);},child:const Text('حفظ'))
    ]));
  }
  Future<void> addSubject()async{
    final c=TextEditingController();
    await showDialog(context:context,builder:(_)=>AlertDialog(title:const Text('إضافة مادة'),content:TextField(controller:c,decoration:const InputDecoration(labelText:'اسم المادة')),actions:[
      TextButton(onPressed:()=>Navigator.pop(context),child:const Text('إلغاء')),
      FilledButton(onPressed:()async{if(c.text.trim().isNotEmpty){widget.data.subjects.add(Subject(id:DateTime.now().microsecondsSinceEpoch.toString(),name:c.text.trim()));await widget.onChanged();setState((){});}Navigator.pop(context);},child:const Text('إضافة'))
    ]));
  }
}
