import 'dart:io';
import 'package:excel/excel.dart';
import 'package:path_provider/path_provider.dart';
import '../models/app_data.dart';
import 'calculation_service.dart';

class ExcelService {
  static Future<String> createClassSheet(AppData data,String grade,{required bool finalSemester}) async {
    final excel=Excel.createExcel();
    final sheet=excel['كشف الدرجات'];
    final headers=['الطالب',...data.subjects.map((s)=>s.name), 'المجموع','النتيجة','الترتيب'];
    for(int c=0;c<headers.length;c++){sheet.cell(CellIndex.indexByColumnRow(columnIndex:c,rowIndex:0)).value=TextCellValue(headers[c]);}
    final ranked=CalculationService.ranked(data.students.where((s)=>s.grade==grade).toList(),data.subjects,finalSemester:finalSemester);
    for(int i=0;i<ranked.length;i++){
      final r=ranked[i];
      sheet.cell(CellIndex.indexByColumnRow(columnIndex:0,rowIndex:i+1)).value=TextCellValue(r.student.name);
      for(int j=0;j<data.subjects.length;j++){
        final sub=data.subjects[j];
        final val=finalSemester?CalculationService.finalSubject(r.student,sub):CalculationService.firstSubject(r.student,sub);
        sheet.cell(CellIndex.indexByColumnRow(columnIndex:j+1,rowIndex:i+1)).value=DoubleCellValue(val);
      }
      final col=data.subjects.length+1;
      sheet.cell(CellIndex.indexByColumnRow(columnIndex:col,rowIndex:i+1)).value=DoubleCellValue(finalSemester?r.finalTotal:r.firstTotal);
      sheet.cell(CellIndex.indexByColumnRow(columnIndex:col+1,rowIndex:i+1)).value=TextCellValue(r.passed?'ناجح':'راسب');
      sheet.cell(CellIndex.indexByColumnRow(columnIndex:col+2,rowIndex:i+1)).value=IntCellValue(i+1);
    }
    final dir=await getApplicationDocumentsDirectory();
    final path='${dir.path}/كشف_${grade}_${finalSemester?"نهائي":"نصفي"}.xlsx';
    final bytes=excel.encode();
    await File(path).writeAsBytes(bytes!);
    return path;
  }
}
