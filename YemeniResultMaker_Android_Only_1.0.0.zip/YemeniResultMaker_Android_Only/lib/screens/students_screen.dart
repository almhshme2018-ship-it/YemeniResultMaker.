import 'package:flutter/material.dart';
import '../models/app_data.dart';
import '../services/storage_service.dart';

class StudentsScreen extends StatefulWidget{
  final AppData data; final Future<void> Function() onChanged;
  const StudentsScreen({super.key,required this.data,required this.onChanged});
  @override State<StudentsScreen> createState()=>_StudentsScreenState();
}
class _StudentsScreenState extends State<StudentsScreen>{
  void addStudent([Student? old]){
    final name=TextEditingController(text:old?.name??'');
    final grade=TextEditingController(text:old?.grade??'');
    showDialog(context:context,builder:(_)=>AlertDialog(
      title:Text(old==null?'إضافة طالب':'تعديل الطالب'),
      content:Column(mainAxisSize:MainAxisSize.min,children:[
        TextField(controller:name,decoration:const InputDecoration(labelText:'اسم الطالب الكامل')),
        TextField(controller:grade,decoration:const InputDecoration(labelText:'الصف')),
      ]),
      actions:[
        TextButton(onPressed:()=>Navigator.pop(context),child:const Text('إلغاء')),
        FilledButton(onPressed:()async{
          if(name.text.trim().isEmpty)return;
          if(old==null) widget.data.students.add(Student(id:DateTime.now().microsecondsSinceEpoch.toString(),name:name.text.trim(),grade:grade.text.trim()));
          else {old.name=name.text.trim();old.grade=grade.text.trim();}
          await widget.onChanged(); setState((){}); if(context.mounted)Navigator.pop(context);
        },child:const Text('حفظ'))
      ],
    ));
  }
  @override Widget build(BuildContext context)=>Scaffold(
    appBar:AppBar(title:const Text('الطلاب'),actions:[IconButton(onPressed:()=>addStudent(),icon:const Icon(Icons.add))]),
    body:widget.data.students.isEmpty?const Center(child:Text('لا يوجد طلاب')):ListView.builder(
      itemCount:widget.data.students.length,
      itemBuilder:(c,i){final s=widget.data.students[i];return Card(child:ListTile(
        title:Text(s.name),subtitle:Text('الصف: ${s.grade}'),
        trailing:PopupMenuButton<String>(onSelected:(v)async{
          if(v=='edit')addStudent(s);
          if(v=='delete'){widget.data.students.remove(s);await widget.onChanged();setState((){});}
        },itemBuilder:(_)=>[const PopupMenuItem(value:'edit',child:Text('تعديل')),const PopupMenuItem(value:'delete',child:Text('حذف'))]),
      ));}
    )
  );
}
