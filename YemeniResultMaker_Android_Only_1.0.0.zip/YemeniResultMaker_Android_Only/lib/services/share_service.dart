import 'package:share_plus/share_plus.dart';
import 'package:url_launcher/url_launcher.dart';

class ShareService {
  static Future<void> shareFile(String path,{String? text}) async {
    await Share.shareXFiles([XFile(path)],text:text);
  }

  static Future<void> whatsapp(String message) async {
    final uri=Uri.parse('https://wa.me/?text=${Uri.encodeComponent(message)}');
    await launchUrl(uri,mode:LaunchMode.externalApplication);
  }
}
